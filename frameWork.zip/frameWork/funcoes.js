function mouseSobre(linha){
    linha.className="ms";
}
function mouseFora(linha){
    linha.className="mf";
}